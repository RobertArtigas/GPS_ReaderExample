﻿using System;
using System.Runtime.InteropServices;
using GarminUSB.Sensor;

namespace GarminGPSUSB
{
    public class GPSUtilities
    {

        [DllImport("GeoMag.dll", EntryPoint = "GetMagVar", SetLastError = true)]
        public static extern double GetMagVar(double lat,
                                                double lon,
                                                double AboveEllipsoid,
                                                double HeightAboveGeoid,
                                                int mm,
                                                int dd,
                                                int yy); 
 
        const int MINUTES_IN_AN_HOUR = 60;
        const int SECONDS_IN_A_MIN = 60;
        const int SECONDS_IN_A_DAY = 86400;
        const int SECONDS_IN_AN_HOUR = 3600;

        static public void ConvertRadiansToDDMMSS(bool lat, double radians, out int degrees, out string Quadriant, out int min, out int sec)
        {
            double tmp = 0;

            tmp = radians * (180 / System.Math.PI);
            degrees = (int)tmp;

            tmp = tmp - degrees;
            tmp = tmp * 60;
            min = (int)tmp;

            tmp = tmp - min;
            tmp = tmp * 60;
            sec = (int)tmp;

            degrees = Math.Abs(degrees);
            min = Math.Abs(min);
            sec = Math.Abs(sec);

            if (lat)
            {
                if (radians < 0)
                {
                    Quadriant = "S";
                }
                else
                {
                    Quadriant = "N";
                }
            }
            else
            {
                if (radians < 0)
                {
                    Quadriant = "W";
                }
                else
                {
                    Quadriant = "E";
                }
            }
        }

        static public void GPSTOWtoUTC(double gps_tow, out string hr, out string min, out string sec)
        {
            UInt64 utemp;
            int itemp;

            int hr1 = 0;
            int hr2 = 0;

            int min1 = 0;
            int min2 = 0;

            int sec1 = 0;
            int sec2 = 0;

            if (gps_tow > 0)
            {
                utemp = (UInt64)gps_tow;
                utemp %= SECONDS_IN_A_DAY;

                itemp = (int)(utemp / SECONDS_IN_AN_HOUR);
                hr1 = itemp / 10;
                hr2 = itemp % 10;

                itemp = (int)((utemp % SECONDS_IN_AN_HOUR) / SECONDS_IN_A_MIN);
                min1 = itemp / 10;
                min2 = itemp % 10;

                itemp = (int)(utemp % SECONDS_IN_A_MIN);
                sec1 = itemp / 10;
                sec2 = itemp % 10;
            }

            hr = hr1.ToString() + hr2.ToString();
            min = min1.ToString() + min2.ToString();
            sec = sec1.ToString() + sec2.ToString();
        }

        static public double radtodeg(double rad)
        {

            double answer = 0;
            answer = rad * (180 / System.Math.PI);

            return answer;
        }

        static public double hypot(double lat_vel, double lon_vel)
        {

            double answer = (lat_vel * lat_vel) + (lon_vel * lon_vel);
            answer = Math.Sqrt(answer);
            
            return answer;
        }

        static double degtom(double deg)
        {

            int ipart = 0;
            double fractional = 0;
            double answer = 0;

            ipart = (int)deg;
            fractional = deg - ipart;
            answer = fractional * 60;

            answer = answer + ipart * 100;

            return answer;

        }

        static string calcChecksum(string Sentence)
        {
            int checksum = 0;

            //GPGGASentence = "GPGGA,185817.23,3257.1203,N,11714.3970,W,1,06,1.8,110.1,M,-36.5,M,,";
            //*52
            for (int i = 0; i < Sentence.Length; i++)
            {
                checksum ^= Convert.ToByte(Sentence[i]);
            }

            return checksum.ToString("X2");
        }

        static public string FormulateGPGGASentenceFromGPS(GarminUSBDevice.pvt_data_type pvt_data,int satsInView)
        {
            string hr;
            string min;
            string sec;

            double posLatMinutes = 0;
            double posLonMinutes = 0;
            double posDegrees = 0;
            double hdop = 0;
            double alt = 0;
            double msl_hght = 0;

            string latQuad;
            string lonQuad;

            string GPGGASentence;

            // Get the current month integer.
            DateTime now = DateTime.Now;
            int yr = now.Year;
            yr = yr - 2000;

            GPSTOWtoUTC(pvt_data.gps_tow - pvt_data.leap_sec, out hr, out min, out sec);

            posDegrees = radtodeg(pvt_data.lat);
            posLatMinutes = degtom(posDegrees);
            if (posDegrees > 0)
            {
                latQuad = "N";
            }
            else
            {
                latQuad = "S";
            }

            posDegrees = radtodeg(pvt_data.lon);
            posLonMinutes = degtom(posDegrees);
            if (posDegrees > 0)
            {
                lonQuad = "E";
            }
            else
            {
                lonQuad = "W";
            }

            posLatMinutes = Math.Round(posLatMinutes, 4);
            posLonMinutes = Math.Round(posLonMinutes, 4);

            posLatMinutes = Math.Abs(posLatMinutes);
            posLonMinutes = Math.Abs(posLonMinutes);

            hdop = Math.Round(pvt_data.eph/10, 1);

            alt = pvt_data.alt - pvt_data.msl_hght;
            alt = Math.Round(alt, 1);

            msl_hght = pvt_data.msl_hght;
            msl_hght = Math.Round(msl_hght, 1);

            GPGGASentence = "GPGGA" + "," + hr + min + sec + "," + posLatMinutes.ToString("00.0000") + "," + latQuad + "," + posLonMinutes.ToString("00.0000") + "," + lonQuad + "," + "1," + satsInView.ToString("00") + "," + hdop + "," + alt + ",M," + msl_hght + ",M,,";
            GPGGASentence = "$" + GPGGASentence + "*" + calcChecksum(GPGGASentence);

            return GPGGASentence;
        }

        static public string FormulateGPRMCSentenceFromGPS(GarminUSBDevice.pvt_data_type pvt_data, double speed_knots, double track)
        {
            string hr;
            string min;
            string sec;

            double posLatMinutes = 0;
            double posLonMinutes = 0;
            double posLatDegrees = 0;
            double posLonDegrees = 0;
 
            double alt = 0;
            double msl_hght = 0;
            string magVar = "";
            string magHem = "";

            string latQuad;
            string lonQuad;

            string GPRMCSentence;

            // Get the current month integer.
            DateTime now = DateTime.Now;
            int yr = now.Year;
            yr = yr - 2000;

            DateTime nowutc = now.ToUniversalTime();
            int yrutc = nowutc.Year;
            yrutc = yrutc - 2000;

            GPSTOWtoUTC(pvt_data.gps_tow - pvt_data.leap_sec, out hr, out min, out sec);

            posLatDegrees = radtodeg(pvt_data.lat);
            posLatMinutes = degtom(posLatDegrees);
            if (posLatDegrees > 0)
            {
                latQuad = "N";
            }
            else
            {
                latQuad = "S";
            }

            posLonDegrees = radtodeg(pvt_data.lon);
            posLonMinutes = degtom(posLonDegrees);
            if (posLonDegrees > 0)
            {
                lonQuad = "E";
            }
            else
            {
                lonQuad = "W";
            }

            posLatMinutes = Math.Round(posLatMinutes, 4);
            posLonMinutes = Math.Round(posLonMinutes, 4);

            posLatMinutes = Math.Abs(posLatMinutes);
            posLonMinutes = Math.Abs(posLonMinutes);

            alt = pvt_data.alt - pvt_data.msl_hght;
            alt = Math.Round(alt, 1);

            msl_hght = pvt_data.msl_hght;
            msl_hght = Math.Round(msl_hght, 1);

            try
            {
                double tmpMagVar = GetMagVar(posLatDegrees, posLonDegrees, pvt_data.msl_hght, pvt_data.alt, now.Month, now.Minute, now.Year);
                magVar = tmpMagVar.ToString("00.0");
                if (tmpMagVar > 0)
                {
                    magHem = "E";
                }
                else
                {
                    magHem = "W";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                magVar = e.Message;

            }

            GPRMCSentence = "GPRMC" + "," + hr + min + sec + ",A," + posLatMinutes.ToString("00.0000") + "," + latQuad + "," + posLonMinutes.ToString("00.0000") + "," + lonQuad + "," + speed_knots.ToString("000.0") + "," + track.ToString("000.0") + "," + nowutc.Day.ToString("00") + nowutc.Month.ToString("00") + yrutc.ToString("00") + "," + magVar + "," + magHem;
            GPRMCSentence = "$" + GPRMCSentence + "*" + calcChecksum(GPRMCSentence);

            return GPRMCSentence;
        }
    }
}
