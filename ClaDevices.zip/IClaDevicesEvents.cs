﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ClaDevices
{
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]  
    public interface IClaDevicesEvents
    {
        //[ComVisible(true)]
        [DispId(301)]
        void TestEvent(string pNmea, string pJson);  

        [DispId(302)]
        void SendToLog(string pParam);

        [DispId(303)]
        void SendDeviceDescription(string pParam);
    }

}
