﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
//using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using GarminUSB.Sensor;
using System.Windows;
using System.Runtime.CompilerServices;
using System.Threading;

namespace ClaDevices
{

    [ProgId("ClaDevices")]
    [ClassInterface(ClassInterfaceType.AutoDispatch)] 
    [ComSourceInterfaces(typeof(IClaDevicesEvents))]
    public partial class Devctrl : UserControl  
    {
        GarminUSBDevice GPS = new GarminUSBDevice();

        string GPS_State = "UnKnown";

        GarminUSBDevice.pvt_data_type saved_pvt_data;

        Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

        private static string FullGpsString = null;
        private static string clarionGpsJson;
        private static string gpsdescription = null;
        //public static string clarionGpsJson;
        public bool isNewFix = false;
        public bool lostFix = false;
        public double m_Accuracy = 0;
        public double m_altitude = double.NaN;
        public double m_speed = 0;
        public double m_course = 0;
        public double mylat = 0;
        public double mylon = 0;
        public int m_numSatellites;
        private NmeaParser.NmeaDevice currentDevice;

       //public virtual void Post(System.Threading.SendOrPostCallback e, object? state) { }

        public event OnTestEvent TestEvent;
        public event OnSendToLog SendToLog;
        public event OnSendDeviceDescription SendDeviceDescription;

        public delegate void OnTestEvent(string pNmea, string pJson);
        public delegate void OnSendToLog(string pParam);
        public delegate void OnSendDeviceDescription(string pParam);




        public Devctrl()
        {
            InitializeComponent();

            DiscoverSerialPort();
        }



        //https://pastebin.com/U0MSNY1p
        [ComRegisterFunction]
        private static void ComRegister(Type t)
        {
            string keyName = @"CLSID\" + t.GUID.ToString("B");

            using (RegistryKey key = Registry.ClassesRoot.OpenSubKey(keyName, true))
            {
                if (key == null)
                    return;


                if (key.CreateSubKey("Control") != null) key.CreateSubKey("Control").Close();

                using (RegistryKey subkey = key.CreateSubKey("MiscStatus"))
                {
                    if (subkey != null) subkey.SetValue("", "131457");
                }
                using (RegistryKey subkey = key.CreateSubKey("TypeLib"))
                {
                    Guid libid = Marshal.GetTypeLibGuidForAssembly(t.Assembly);
                    if (subkey != null) subkey.SetValue("", libid.ToString("B"));
                }
                using (RegistryKey subkey = key.CreateSubKey("Version"))
                {
                    Version ver = t.Assembly.GetName().Version;
                    string version = string.Format("{0}.{1}", ver.Major, ver.Minor);

                    if (String.Compare(version, "0.0", false) == 0)

                        version = "1.0";
                    if (subkey != null) subkey.SetValue("", version);
                }
            }
        }

        [ComUnregisterFunction]
        private static void ComUnregister(Type t)
        {
            Registry.ClassesRoot.DeleteSubKeyTree(@"CLSID\" + t.GUID.ToString("B"));
        }

        public string GetFullGpsString()
        {
            return GpsTextBox.Text.ToString();  //FullGpsString;
        }

        public void StartDevice(SerialPort port)
        {
            if (port != null)
            {
                var device = new NmeaParser.SerialPortDevice(port);
                device.MessageReceived += OnNmeaMessageReceived;
                device.OpenAsync();
            }
        }

        Dictionary<string, List<NmeaParser.Messages.Gsv>> gsvMessages = new Dictionary<string, List<NmeaParser.Messages.Gsv>>();

        public void OnNmeaMessageReceived(object sender, NmeaParser.NmeaMessageReceivedEventArgs args)
        {
            
            var message = args.Message;
            ParseMessage(message);
            if (message.ToString() != null)
            {
                SendToUDP(args.Message.ToString()+ "\r\n");
                FullGpsString = args.Message.ToString();
                GpsTextBox.Text = args.Message.ToString();
                clarionGpsJson = "{ \"nmeagroup\":{ \"latitude\":" + mylat + ",\"longitude\":" + mylon + ",\"speed\":" + m_speed + ",\"heading\":\"" + m_course + "\",\"numsatellites\":" + m_numSatellites + ",\"quality\":\"" + isNewFix + "\"} }";
                
                try
                {
                    Invoke((Action)(() => TestEvent(FullGpsString, clarionGpsJson)));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }
            }
        }

        public void ParseMessage(NmeaParser.Messages.NmeaMessage message)
        {
            if (message is NmeaParser.Messages.Garmin.Pgrme)
            {
                m_Accuracy = ((NmeaParser.Messages.Garmin.Pgrme)message).HorizontalError;
            }
            else if (message is NmeaParser.Messages.Gst Gst)
            {
                Gst = ((NmeaParser.Messages.Gst)message);
                m_Accuracy = Math.Sqrt(Gst.SigmaLatitudeError * Gst.SigmaLatitudeError + Gst.SigmaLongitudeError * Gst.SigmaLongitudeError);
            }
            else if (message is NmeaParser.Messages.Gga Gga)
            {
                Gga = ((NmeaParser.Messages.Gga)message);
                isNewFix = Gga.Quality != NmeaParser.Messages.Gga.FixQuality.Invalid;
                lostFix = !isNewFix;
                m_altitude = Gga.Altitude;
                mylat = Gga.Latitude;
                mylon = Gga.Longitude;
                m_numSatellites = Gga.NumberOfSatellites;
            }
            else if (message is NmeaParser.Messages.Rmc Rmc)
            {
                Rmc = (NmeaParser.Messages.Rmc)message;
                if (Rmc.Active)
                {
                    isNewFix = true;
                    m_speed = Rmc.Speed * 1.151; //Convert from Knots to Mph
                    m_course = Rmc.Course;
                    mylat = Rmc.Latitude;
                    mylon = Rmc.Longitude;
                }
                else lostFix = true;
            }
            else if (message is NmeaParser.Messages.Gsa Gsa)
            {
                Gsa = (NmeaParser.Messages.Gsa)message;
            }
            if (isNewFix)
            {
                //base.UpdateLocation(new Esri.ArcGISRuntime.Location.Location(new MapPoint(lon, lat, m_altitude, SpatialReferences.Wgs84), m_Accuracy, m_speed, m_course, false));
            }
            else if (lostFix)
            {
                Trace.WriteLine("Lost Fix!!!!");
            }
        }


        //Attempts to perform an auto discovery of serial ports
        private async void DiscoverSerialPort()
        {
            System.IO.Ports.SerialPort port = await Task.Run<System.IO.Ports.SerialPort>(() => {
                return FindPort(); 
            });
            
            if (port != null) //we found a port
            {
                Trace.WriteLine("GPS Port Found");
                //Send Log Entry Back to Clarion
                try
                {
                    Invoke((Action)(() => SendToLog("GPS Port Found")));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }
                //Send Device Description Back to Clarion
                try
                {
                    Invoke((Action)(() => SendDeviceDescription(gpsdescription)));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }

                StartDevice(port);
            }
            else
                if (port == null)
            {
                Trace.WriteLine("No GPS port found");
                try
                {
                    Invoke((Action)(() => SendToLog("No GPS port found")));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }
                GPS.initialize(ConnectionStatus, ProcessPVTData, ProcessSatData);
            }
        }

        //Iterates all serial ports and attempts to open them at different baud rates
        //and looks for a GPS message.
        public static System.IO.Ports.SerialPort FindPort()  //IProgress<string> progress = null
        {
            var ports = System.IO.Ports.SerialPort.GetPortNames().OrderBy(s => s);
            foreach (var portName in ports)
            {
                using (var port = new System.IO.Ports.SerialPort(portName))
                {
                    var defaultRate = port.BaudRate;
                    List<int> baudRatesToTest = new List<int>(new[] { 9600, 4800, 115200, 19200, 57600, 38400, 2400 }); //Ordered by likelihood
                                                                                                                        //Move default rate to first spot
                    if (baudRatesToTest.Contains(defaultRate)) baudRatesToTest.Remove(defaultRate);
                    baudRatesToTest.Insert(0, defaultRate);
                    foreach (var baud in baudRatesToTest)
                    {

                        //if (progress != null)
                        //    progress.Report(string.Format("Trying {0} @ {1}baud", portName, port.BaudRate));
                        //Trace.WriteLine("Trying Port"+portName+" at Baud Rate "+port.BaudRate);
                        //SetLogEntry("Trying Port" + portName + " at Baud Rate " + port.BaudRate);
                        port.BaudRate = baud;
                        port.ReadTimeout = 1000; //this might not be long enough
                        bool success = false;
                        try
                        {
                            port.Open();
                            if (!port.IsOpen)
                                continue; //couldn't open port
                            try
                            {
                                port.ReadTo("$GP");
                            }
                            catch (TimeoutException)
                            {
                                continue;
                            }
                            success = true;
                        }
                        catch
                        {
                            //Error reading
                        }
                        finally
                        {
                            port.Close();
                        }
                        if (success)
                        {
                            gpsdescription = portName + " at Baud Rate: " + baud;
                            return new System.IO.Ports.SerialPort(portName, baud);
                        }
                    }
                }
            }
            return null;
        }

        // function queries the system using WMI and gets an arraylist of all com port devices     
        public string getFriendlyNameList()  //ArrayList
        {
            var i = 0;
            string mfg = "";
            string status = "";
            //int portnum = 1;
            string foundname = "";
            Trace.WriteLine("getFriendlyNameList Called");

            //ArrayList deviceList = new ArrayList();

            // getting a list of all available com port devices and their friendly names     
            // must add System.Management DLL resource to solution before using this     
            // Project -> Add Reference -> .Net tab, choose System.Management     

            // source:     
            // http://www.codeproject.com/KB/system/hardware_properties_c_.aspx     

            ManagementObjectSearcher searcher = new ManagementObjectSearcher("Select * from Win32_PnpEntity");  //Name

            foreach (ManagementObject devices in searcher.Get())
            {
                if (devices.GetPropertyValue("Name") != null)
                {
                    i++;
                    string name = devices.GetPropertyValue("Name").ToString();
                    string deviceid = devices.GetPropertyValue("DeviceID").ToString();

                    if (devices.GetPropertyValue("Status") != null)
                    {
                        status = devices.GetPropertyValue("Status").ToString();
                    }

                    string pnpclass = devices.GetPropertyValue("PNPClass").ToString();

                    if (devices.GetPropertyValue("Manufacturer") != null)
                    {
                        mfg = devices.GetPropertyValue("Manufacturer").ToString();
                    }

                    Trace.WriteLine("Name:" + name + "  Description:" + deviceid + "  Status:" + status + "  Class:" + pnpclass);

                    //if (searchclass != null)
                    //{
                        if (name.Contains("Prolific"))
                        {
                            //TestCallToClarion();
                            foundname = name;
                        }
                }

            }

            //searcher.Dispose();
            return foundname;
        }

        public string GetNmeaString()
        {
            return FullGpsString;
        }

        public string GetGpsData()
        {
            return clarionGpsJson;
        }

        public void SendToUDP(string pmessage)
        {

            IPAddress serverAddr = IPAddress.Parse("127.0.0.1");
            IPEndPoint endPoint = new IPEndPoint(serverAddr, 17335);
            string s = pmessage.ToString();
            for (int i = 0; i < s.Length; i++)
            {
                //Trace.WriteLine(s[i].ToString());
                string buf = s[i].ToString();
                byte[] send_buffer = Encoding.ASCII.GetBytes(s[i].ToString());

                SocketAsyncEventArgs e = new SocketAsyncEventArgs();
                e.SetBuffer(send_buffer, 0, send_buffer.Length);
                sock.SendTo(send_buffer, endPoint);
                //	e.Completed += new EventHandler<SocketAsyncEventArgs>(SendCallback);
            }
        }

        void ConnectionStatus(Boolean connected)
        {
            if (connected)
            {
                GPS_State = "GPS Active";
                //Trace.WriteLine("GPS Active");
            }
            else
            {
                GPS_State = "Searching";
                //Trace.WriteLine("GPS Searching");
            }
        }

        void ProcessPVTData(GarminUSBDevice.pvt_data_type pvt_data)
        {
            const bool lat = true;
            const bool lon = false;

            string latstring = "";
            string lonstring = "";

            double lattitude = 0;
            double longitude = 0;

            string nmeasentence = "";
            

            string thr;
            string tmin;
            string tsec;

            int degrees = 0;
            string Quadriant = "?";
            int min = 0;
            int sec = 0;

            double speed_knots = 0;
            double speed_mph = 0;
            double track = 0;

            saved_pvt_data = pvt_data;

            GPS_State = "UnKnown";
            switch (pvt_data.fix)
            {
                case 1:
                    GPS_State = "Searching";
                    try
                    {
                        Invoke((Action)(() => SendToLog("Searching for Garmin Device")));
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.GetType().Name + " : " + e.Message);
                    }
                    break;
                case 2:
                    GPS_State = "Aquiring";
                    try
                    {
                        Invoke((Action)(() => SendToLog("Aquiring for Garmin Device")));
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.GetType().Name + " : " + e.Message);
                    }
                    break;
                case 3:
                    GPS_State = "GPS Active";
                    try
                    {
                        Invoke((Action)(() => SendToLog("Garmin Device Active")));
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.GetType().Name + " : " + e.Message);
                    }
                    isNewFix = true;
                    break;
            }

            if (GPS_State == "GPS Active")
            {
                GarminGPSUSB.GPSUtilities.ConvertRadiansToDDMMSS(lat, pvt_data.lat, out degrees, out Quadriant, out min, out sec);
                mylat = ConvertDegreeAngleToDouble(degrees, min, sec, Quadriant);
                //Trace.WriteLine("newlat = " + newlat);
                latstring = degrees.ToString() + '\u00B0'.ToString() + " " + min.ToString() + "' " + sec.ToString() + '"'.ToString() + " " + Quadriant;
                

                GarminGPSUSB.GPSUtilities.ConvertRadiansToDDMMSS(lon, pvt_data.lon, out degrees, out Quadriant, out min, out sec);
                mylon = ConvertDegreeAngleToDouble(degrees, min, sec, Quadriant);
                lonstring = degrees.ToString() + '\u00B0'.ToString() + " " + min.ToString() + "' " + sec.ToString() + '"'.ToString() + " " + Quadriant;

                gpsdescription = GPS.GetProductDescription();
                Trace.WriteLine(gpsdescription);
                try
                {
                    Invoke((Action)(() => SendToLog("Garmin Device = " + gpsdescription)));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }

                try
                {
                    Invoke((Action)(() => SendDeviceDescription(gpsdescription)));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }


                FullGpsString = GarminGPSUSB.GPSUtilities.FormulateGPRMCSentenceFromGPS(pvt_data, speed_knots, track) + "\r\n";
                GpsTextBox.Text = FullGpsString;
                //Trace.WriteLine(nmeasentence);
                clarionGpsJson = "{ \"nmeagroup\":{ \"latitude\":" + mylat + ",\"longitude\":" + mylon + ",\"speed\":" + m_speed + ",\"heading\":\"" + m_course + "\",\"numsatellites\":" + m_numSatellites + ",\"quality\":\"" + isNewFix + "\"} }";
                SendToUDP(FullGpsString);
            }
        }

        double ConverSNR(UInt16 snr)
        {
            const double MIN_SNR = 1000;
            const double MAX_SNR = 4400;
            const double MAX_NMEA_SNR = 99;
            double scaleFactor = MAX_NMEA_SNR / (MAX_SNR - MIN_SNR);

            double tmp = (snr - MIN_SNR) * scaleFactor;

            return tmp;
        }

        void ProcessSatData(GarminUSBDevice.sat_data_type[] sat_data_array)
        {
            int satsInView = 0;
            //string nmeasentence = "";

            if (sat_data_array[0].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[1].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[2].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[3].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[4].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[5].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[6].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[7].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[8].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[9].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[10].status == 13)
            {
                satsInView++;
            }

            if (sat_data_array[11].status == 13)
            {
                satsInView++;
            }

            if (satsInView > 0 && GPS_State == "GPS Active")
            {
                FullGpsString = GarminGPSUSB.GPSUtilities.FormulateGPGGASentenceFromGPS(saved_pvt_data, satsInView) + "\r\n";
                GpsTextBox.Text = FullGpsString;
                clarionGpsJson = "{ \"nmeagroup\":{ \"latitude\":" + mylat + ",\"longitude\":" + mylon + ",\"speed\":" + m_speed + ",\"heading\":\"" + m_course + "\",\"numsatellites\":" + m_numSatellites + ",\"quality\":\"" + isNewFix + "\"} }";
                SendToUDP(FullGpsString);
                try
                {
                    Invoke((Action)(() => TestEvent(FullGpsString, clarionGpsJson)));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.GetType().Name + " : " + e.Message);
                }
            }
        }

        public double ConvertDegreeAngleToDouble(int pDeg, int pMin, int pSec, string pQuad)
        {
            //string pointstring = "";
            var degrees = pDeg;
            decimal min = ((decimal)pMin / (decimal)60);
            decimal sec = ((decimal)pSec / (decimal)3600);
            double newpoint = (double)(degrees + decimal.Add(min, sec));
            switch (pQuad)
            {
                case "N":
                    break;
                case "S":
                    newpoint = newpoint * -1; //newpoint.ToString();
                    break;
                case "E":
                    break;
                case "W":
                    newpoint = newpoint * -1; //"-" + newpoint.ToString();
                    break;
            }
            return newpoint;
        }

    }
}
